# Changelog

## 2.0.0

- Renamed the package to Infini Tweaks and kept it as one DLL with no MTFO dependency.
- Added numeric recoil, aim-punch, and stamina-cost multipliers.
- Added toggles for melee charge recovery, melee stamina cost, jump stamina cost, and teammate bullet damage.
- Added optional Better Maps rendering, accessible-area filtering, orientation correction, and icon priority.
- Added selectable official Original R6 and current R8 HEL Gun and Sniper presets.
- Corrected stamina scaling before clamping and limited it to the local human player.
- Added isolated full recoil definitions for weapon presets and scaled procedural firing recoil with the global multiplier.
- Scoped teammate protection to local outgoing bullets and made aim-punch scaling per hit.
- Corrected map bounds writeback and guaranteed temporary render-resource cleanup.
- Added historical-data and player-patch regression coverage.

## 1.0.0

- Added configurable positive or negative flashlight range adjustment.
- Added configurable positive or negative flashlight cone-angle adjustment.
- Added optional local first-person flashlight sway removal.
- Preserved GTFO's native flashlight toggle, equipment, detection, and network state handling.
