# Infini Tweaks

A configurable GTFO quality-of-life collection in one DLL. Every added gameplay module defaults to disabled or vanilla strength; the original flashlight improvements remain enabled by default.

Infini Tweaks does not use MTFO and never controls the flashlight's on/off state.

## Features and configuration

The config is generated at `BepInEx/config/NAinfini.InfiniTweaks.cfg` after the first launch.

```ini
[Flashlight]
RangeAdjustmentMeters = 10
AngleAdjustmentDegrees = 35
NoSway = true

[Combat]
# 1 = original, 0.5 = half, 0 = no recoil.
RecoilMultiplier = 1
# Accepted range: 0.1 to 1.
AimPunchMultiplier = 1
TeammatesIgnoreBullets = false

[Stamina]
# 1 = original, 0.5 = half costs, 0 = infinite stamina.
StaminaCostMultiplier = 1
EnableChargeRecovery = false
RemoveMeleeCost = false
RemoveJumpCost = false

[Map]
EnableBetterMaps = false
BlurScale = 0.15
OutlineScale = 0.05

[Weapon Presets]
# Disabled, OriginalR6, or R8Current
HelGunVersion = Disabled
SniperVersion = Disabled
```

Restart the game after editing the config.

Flashlight ranges are clamped to 0.1–100 metres and cone angles to Unity's valid 1–179 degree range. Positive or negative adjustments are supported.

The recoil multiplier scales aiming recoil, procedural weapon position/rotation impulses, and firing concussion after the selected weapon preset is applied. It does not change accuracy, spread, recoil recovery, or baked firing animations. `StaminaCostMultiplier = 0` keeps local stamina full, including during combat; nonzero values scale action costs before the game's stamina clamp. Recovery strength and the native BPM display are retained. The melee and jump toggles remove only those action costs (melee pushes retain their normal cost).

Stamina changes apply only to the local human player. `TeammatesIgnoreBullets` prevents **your bullets** from hurting teammates, including bots. It does not protect you from teammates' bullets, change enemy damage, or make bullets penetrate teammates. Each teammate must enable it to prevent their own outgoing friendly fire.

Better Maps removes inaccessible navmesh from the map, reduces blur, corrects reversed map icons, and draws resource lockers, boxes, terminals, disinfection stations, generators, and bulkhead controls above minor icons.

The HEL Gun and Sniper presets restore the official original R6 or current R8 combat stats, including full recoil definitions. Models, localization, animations, and sentry settings remain those of the running game. Private recoil definitions keep presets from affecting other weapons that share the native recoil data. `Disabled` leaves weapon stats untouched; the independent global recoil multiplier still applies if it is below 1.

| Weapon | Preset | Damage | Magazine | Ammo cost | Shot delay | Charge |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| HEL Gun | OriginalR6 | 16.25 | 9 | 6.5 | 0.1 s | 0.1 s |
| HEL Gun | R8Current | 16.25 | 9 | 5.74 | 0.1 s | 0.2 s |
| Sniper | OriginalR6 | 40.01 | 3 | 15 | 0.5 s | 0 s |
| Sniper | R8Current | 40.01 | 2 | 17.5 | 0.8 s | 0 s |

## Installation

1. Install [BepInExPack for GTFO](https://thunderstore.io/c/gtfo/p/BepInEx/BepInExPack_GTFO/).
2. Put `InfiniTweaks.dll` in `BepInEx/plugins/InfiniTweaks/`.
3. Remove standalone mods for any Infini Tweaks feature you enable to prevent overlapping patches.

Do not combine enabled modules with Flashlight Overhaul, BrighterLights, NoSway, LightsAdjustment, APEX Prisoners recoil, HeroicHeart, TeammatesIgnoreBullets, AimPunchAdjustment, BetterMaps, R6_HELGun, or MakeSniperGreatAgain.

When upgrading from Infini Flashlight, remove its DLL to avoid applying beam adjustments twice, then copy your beam values into the new config's `Flashlight` section. The old config is not loaded automatically. Hot unloading is not supported; restart the game to remove applied data/prefab changes.

## Building

.NET 6 targeting files are required. Point the build at a modded GTFO profile's `BepInEx` directory:

```powershell
$env:GTFO_BEPINEX_PATH = "$env:APPDATA\r2modmanPlus-local\GTFO\profiles\YourProfile\BepInEx"
dotnet build -c Release
```

Offline regression tests link the production player patches and datablock code against managed game doubles:

```powershell
dotnet run --project tests/Regression.csproj -c Release
```

They check low-stamina clamping, local/remote/bot scope, friendly-fire direction, repeated-hit aim punch, disabled presets, shared recoil isolation, all covered historical numeric values, recoil scaling, flashlight clamps, and duplicate initialization. They do not run Unity, IL2CPP detours, rendering, or multiplayer replication.

## Sources

Weapon fixtures: [OriginalDataBlocks](https://github.com/UntiIted/OriginalDataBlocks), original R6 commit `3376fbd` and current R8 commit `6244c01`. The test fixture only removes derived Vector metadata such as `normalized` and `magnitude`.

Map behavior is based on [GTFO-Modding/BetterMaps](https://github.com/GTFO-Modding/BetterMaps). HeroicHeart, TeammatesIgnoreBullets, AimPunchAdjustment, and APEX Prisoners informed the feature selection; their standalone DLLs are not bundled.
